#NAME: ASHESI CRENTSIL
#ID: 10974881
#PROJECT 2, QUESTION 1

import PySimpleGUI as sg
import pyttsx3

sg.theme('DarkAmber')

# To define the layout of the GUI
layout = [
    [sg.Text("Enter Text to Speak: "), sg.InputText(key="-INPUT-")],
    [sg.Text("Select Voice Type"), sg.Radio("Male Voice", "RADIO1", default=True, key="-MALE-"), sg.Radio("Female Voice", "RADIO1", key="-FEMALE-")],
    [sg.Text("Volume:"), sg.Slider(range=(0, 1), resolution=0.1, default_value=1, orientation="h", key="-VOLUME-")],
    [sg.Text("Speed:"), sg.Slider(range=(0, 1), resolution=0.1, default_value=0.5, orientation="h", key="-SPEED-")],
    [sg.Button("Speak", key="-SPEAK-"), sg.Button("Exit", key="-EXIT-")]
]

# Creating the GUI window
window = sg.Window("Text-to-Speech App", layout)

engine = pyttsx3.init()

# Create event loop
while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == "-EXIT-":
        break
    if event == "-SPEAK-":
        text = values["-INPUT-"]
        if values["-MALE-"]:
            engine.setProperty("voice", "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_EN-US_DAVID_11.0")
        elif values["-FEMALE-"]:
            engine.setProperty("voice", "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_EN-US_ZIRA_11.0")
        volume = values["-VOLUME-"]
        speed = values["-SPEED-"]
        engine.setProperty("volume", volume)
        engine.setProperty("rate", speed * 200)
        engine.say(text)
        engine.runAndWait()

window.close()
engine.stop()
