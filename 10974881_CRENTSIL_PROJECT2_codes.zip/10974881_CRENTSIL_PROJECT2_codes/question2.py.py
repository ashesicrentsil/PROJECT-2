#NAME: ASHESI CRENTSIL
#ID: 10974881
#PROJECT 2, QUESTION 2

import qrcode
import PySimpleGUI as sg

sg.theme('darkBlue')

# Define the layout of the GUI
layout = [[sg.Text('To generate QR code, ENTER TEXT:')],
          [sg.InputText()],
          [sg.Text('Select QR code color:')],
          [sg.Combo(['black', 'blue', 'red', 'green', 'yellow'], default_value='black', key='fill_color')],
          [sg.Text('Select background color:')],
          [sg.Combo(['white', 'black', 'blue', 'red', 'green', 'yellow'], default_value='white', key='back_color')],
          [sg.Text('Select QR code size (pixels):')],
          [sg.Slider(range=(100, 500), default_value=250, orientation='h', size=(20, 15), key='size')],
          [sg.Button('Create QR code'), sg.Button('Exit')]]

# Creating the GUI window
window = sg.Window('QR Code Generator', layout)

# Create event loop
while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Exit':
        break
    elif event == 'Create QR code':

        # Get the text from the input box
        text = values[0]
        if text.strip():

            # Get the selected colors and size
            fill_color = values['fill_color']
            back_color = values['back_color']
            size = values['size']

            # Generate the QR code with the selected colors and size
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(text)
            qr.make(fit=True)
            img = qr.make_image(fill_color=fill_color, back_color=back_color).resize((int(size), int(size)))

            # Save the generated QR code image to a file
            img_file = 'qr_code.png'
            img.save(img_file)

            # Display a popup message with the generated QR code image
            sg.popup('QR code generated!', image=img_file)

            window.close()
        else:
            # Show an error message if the input text is empty
            sg.popup_error('Please enter some text')
